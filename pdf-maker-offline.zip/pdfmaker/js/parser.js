/* parser.js - turns raw text into blocks (headings, paragraphs, lists, quotes, rules) */
(function (PM) {
  'use strict';

  /* Inline: **bold**, *italic*, ***both***, \* for a literal asterisk. Returns [{t,b,i}] */
  PM.inline = function (s) {
    s = String(s).replace(/\\\*/g, '\u0001');
    const parts = [];
    const re = /\*\*\*|\*\*|\*/g;
    let last = 0, m;
    while ((m = re.exec(s))) {
      if (m.index > last) parts.push({ t: s.slice(last, m.index) });
      const prev = s[m.index - 1], next = s[m.index + m[0].length];
      parts.push({
        mark: m[0],
        open: !!next && !/\s/.test(next),
        close: !!prev && !/\s/.test(prev)
      });
      last = m.index + m[0].length;
    }
    if (last < s.length) parts.push({ t: s.slice(last) });

    const stack = [];
    parts.forEach((p, idx) => {
      if (!p.mark) return;
      if (p.close) {
        let j = stack.length - 1;
        while (j >= 0 && parts[stack[j]].mark !== p.mark) j--;
        if (j >= 0) {
          parts[stack[j]].paired = true;
          p.paired = true;
          stack.length = j;
          return;
        }
      }
      if (p.open) stack.push(idx);
    });

    const runs = [];
    let b = false, i = false;
    const add = (t) => {
      if (!t) return;
      t = t.replace(/\u0001/g, '*');
      const l = runs[runs.length - 1];
      if (l && l.b === b && l.i === i) l.t += t; else runs.push({ t, b, i });
    };
    for (const p of parts) {
      if (p.mark) {
        if (p.paired) {
          if (p.mark === '***') { b = !b; i = !i; }
          else if (p.mark === '**') b = !b;
          else i = !i;
        } else add(p.mark);
      } else add(p.t);
    }
    return runs;
  };

  function isCapsHeading(t) {
    if (t.length < 3 || t.length > 60) return false;
    if (!/\p{L}/u.test(t)) return false;
    if (t !== t.toUpperCase() || t === t.toLowerCase()) return false;
    if (/[.,;!?]$/.test(t)) return false;
    if (t.split(/\s+/).length > 8) return false;
    return true;
  }

  PM.parse = function (text, opts) {
    const keep = !!(opts && opts.keepBreaks);
    const sep = keep ? '\n' : ' ';
    const lines = String(text).replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').replace(/\t/g, '    ').split('\n');
    const blocks = [];
    let buf = null;

    const flush = () => {
      if (!buf) return;
      const src = buf.lines.map((s) => s.trim()).filter(Boolean).join(sep);
      if (src) blocks.push({ type: buf.type, src });
      buf = null;
    };
    const blank = (s) => s === undefined || s.trim() === '';

    for (let n = 0; n < lines.length; n++) {
      const line = lines[n];
      const t = line.trim();
      if (t === '') { flush(); continue; }
      let m;

      if ((m = /^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(t))) {
        flush();
        blocks.push({ type: 'heading', level: Math.min(3, m[1].length), src: m[2] });
        continue;
      }
      if (/^([-*_])(\s*\1){2,}$/.test(t)) { flush(); blocks.push({ type: 'rule' }); continue; }

      if (isCapsHeading(t) && blank(lines[n - 1]) && blank(lines[n + 1])) {
        flush();
        blocks.push({ type: 'heading', level: 2, src: t });
        continue;
      }

      if ((m = /^(\s*)([-*•▪◦‣–])\s+(\S.*)$/.exec(line))) {
        flush();
        const ind = m[1].length;
        blocks.push({ type: 'li', ordered: false, marker: '\u2022', level: ind >= 6 ? 2 : ind >= 2 ? 1 : 0, src: m[3].trim() });
        continue;
      }
      if ((m = /^(\s*)(\d{1,3})([.)])\s+(\S.*)$/.exec(line))) {
        flush();
        const ind = m[1].length;
        blocks.push({ type: 'li', ordered: true, marker: m[2] + m[3], level: ind >= 6 ? 2 : ind >= 2 ? 1 : 0, src: m[4].trim() });
        continue;
      }

      if ((m = /^>\s?(.*)$/.exec(t))) {
        if (!buf || buf.type !== 'quote') { flush(); buf = { type: 'quote', lines: [] }; }
        buf.lines.push(m[1]);
        continue;
      }

      const lastB = blocks[blocks.length - 1];
      if (!buf && lastB && lastB.type === 'li' && /^\s{2,}/.test(line)) {
        lastB.src += sep + t;
        continue;
      }

      if (!buf || buf.type !== 'para') { flush(); buf = { type: 'para', lines: [] }; }
      buf.lines.push(line);
    }
    flush();

    blocks.forEach((b, i) => {
      if (b.src !== undefined) { b.runs = PM.inline(b.src); delete b.src; }
      if (b.type === 'li') { const nx = blocks[i + 1]; b.last = !nx || nx.type !== 'li'; }
    });
    return blocks.filter((b) => b.type === 'rule' || (b.runs && b.runs.length));
  };
})(window.PM = window.PM || {});
