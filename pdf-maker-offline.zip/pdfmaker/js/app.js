/* app.js - UI wiring */
(function (PM) {
  'use strict';
  const $ = (id) => document.getElementById(id);

  const FONT_FILES = {
    r: ['fonts/DejaVuSans-Regular.ttf', 'DejaVuSans'],
    b: ['fonts/DejaVuSans-Bold.ttf', 'DejaVuSans-Bold'],
    i: ['fonts/DejaVuSans-Oblique.ttf', 'DejaVuSans-Oblique'],
    bi: ['fonts/DejaVuSans-BoldOblique.ttf', 'DejaVuSans-BoldOblique']
  };
  const fontCache = {};
  async function loadFonts(keys) {
    const out = {};
    for (const k of keys) {
      if (!fontCache[k]) {
        let res;
        try { res = await fetch(FONT_FILES[k][0]); } catch (e) { res = null; }
        if (!res || !res.ok) throw new Error('Could not load the built-in fonts. Open the app once, then try again.');
        fontCache[k] = PM.parseTTF(await res.arrayBuffer(), FONT_FILES[k][1]);
      }
      out[k] = fontCache[k];
    }
    return out;
  }

  const PAGES = { a4: [595.28, 841.89], letter: [612, 792] };
  const MARGINS = { narrow: 40, normal: 56, wide: 72 };
  const OPTIONS = {
    size: [['12', '12'], ['14', '14'], ['16', '16'], ['18', '18']],
    align: [['left', 'Left'], ['center', 'Center'], ['right', 'Right'], ['justify', 'Justify']],
    spacing: [['1', '1.0'], ['1.25', '1.25'], ['1.5', '1.5'], ['2', '2.0']],
    page: [['a4', 'A4'], ['letter', 'Letter']],
    margin: [['narrow', 'Narrow'], ['normal', 'Normal'], ['wide', 'Wide']]
  };
  const DEFAULTS = { size: '12', align: 'left', spacing: '1.25', page: 'a4', margin: 'normal', keep: false };
  let settings = Object.assign({}, DEFAULTS);

  const store = {
    get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } }
  };

  const SAMPLE = {
    title: 'Weekly Report',
    text: `# Overview
This report summarises what the team did this week. It is written as **plain text** and arranged automatically into a clean document with *headings*, paragraphs and lists.

## Highlights
- Launched the new **offline** mode
- Fixed 14 reported bugs
  - 9 in the mobile app
  - 5 on the website
- Collected feedback from *32* customers

## Next steps
1. Review the feedback
2. Plan the next release
3. Share the plan with the team

> Good tools disappear into the work.

TEXT IN OTHER LANGUAGES

Ẹ káàbọ̀ sí ìròyìn ọ̀sẹ̀ yìí. Привет, мир! Γειά σου Κόσμε! Ça va très bien, merci. Zażółć gęślą jaźń.

---

Thank you for reading.`
  };

  function buildSegs() {
    document.querySelectorAll('.seg').forEach((seg) => {
      const name = seg.dataset.name;
      OPTIONS[name].forEach(([val, label]) => {
        const l = document.createElement('label');
        const inp = document.createElement('input');
        inp.type = 'radio'; inp.name = name; inp.value = val;
        const sp = document.createElement('span'); sp.textContent = label;
        l.append(inp, sp); seg.appendChild(l);
        inp.addEventListener('change', () => { settings[name] = val; store.set('pm.settings', settings); });
      });
    });
  }
  function applySettings() {
    Object.keys(OPTIONS).forEach((name) => {
      const el = document.querySelector('input[name="' + name + '"][value="' + settings[name] + '"]');
      if (el) el.checked = true;
    });
    $('keep').checked = !!settings.keep;
  }

  function wordCount(s) { const m = s.trim().match(/\S+/g); return m ? m.length : 0; }
  function updateCount() { const n = wordCount($('text').value); $('count').textContent = n + (n === 1 ? ' word' : ' words'); }
  function saveDraft() { store.set('pm.draft', { title: $('title').value, text: $('text').value }); }

  function showMsg(t) { const m = $('msg'); m.textContent = t; m.hidden = !t; }
  function showWarn(t) { const m = $('warn'); m.textContent = t; m.hidden = !t; }

  function slug(t) {
    const s = (t || '').normalize('NFKC').replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 50);
    return (s || 'document') + '.pdf';
  }

  let current = null; // {blob, name, url}
  function setResult(blob, name, pages) {
    if (current) URL.revokeObjectURL(current.url);
    current = { blob, name, url: URL.createObjectURL(blob) };
    $('fileName').textContent = name;
    const kb = blob.size / 1024;
    $('fileInfo').textContent = pages + (pages === 1 ? ' page' : ' pages') + ' · ' + (kb >= 1024 ? (kb / 1024).toFixed(1) + ' MB' : Math.round(kb) + ' KB');
    $('shareNote').hidden = true;
    $('result').hidden = false;
    $('result').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  async function generate() {
    showMsg(''); showWarn('');
    const text = $('text').value;
    if (!text.trim()) { showMsg('Please paste or type some text first.'); $('text').focus(); return; }
    const btn = $('gen');
    btn.disabled = true; btn.textContent = 'Generating…';
    try {
      await new Promise((r) => setTimeout(r, 30)); // let the button repaint
      const title = $('title').value.trim();
      const blocks = PM.parse(text, { keepBreaks: settings.keep });
      if (!blocks.length) throw new Error('There is no text to put in the PDF.');
      const fonts = await loadFonts(PM.neededStyles(blocks, !!title));
      const [pageW, pageH] = PAGES[settings.page];
      const lay = PM.layout(blocks, title, {
        pageW, pageH, margin: MARGINS[settings.margin], size: parseFloat(settings.size),
        align: settings.align, spacing: parseFloat(settings.spacing)
      }, fonts);
      const bytes = await PM.buildPDF({ pages: lay.pages, pageW, pageH, fonts, title: title || 'Document' });
      setResult(new Blob([bytes], { type: 'application/pdf' }), slug(title), lay.pages.length);
      if (lay.missing.length) {
        const ex = lay.missing.slice(0, 8).join(' ');
        showWarn('Some characters can’t be drawn by the built-in font and were replaced with “?”: ' + ex + (lay.missing.length > 8 ? ' …' : ''));
      }
    } catch (e) {
      console.error(e);
      showMsg(e && e.message ? e.message : 'Something went wrong while making the PDF.');
    } finally {
      btn.disabled = false; btn.textContent = 'Generate PDF';
    }
  }

  function save() {
    if (!current) return;
    const a = document.createElement('a');
    a.href = current.url; a.download = current.name;
    document.body.appendChild(a); a.click(); a.remove();
  }
  async function share() {
    if (!current) return;
    const note = $('shareNote');
    const file = new File([current.blob], current.name, { type: 'application/pdf' });
    try {
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: current.name });
        note.hidden = true;
      } else {
        note.textContent = 'Sharing isn’t available here. Use “Save to phone” instead.';
        note.hidden = false;
      }
    } catch (e) {
      if (e && e.name !== 'AbortError') { note.textContent = 'Couldn’t share the file. Use “Save to phone” instead.'; note.hidden = false; }
    }
  }

  async function paste() {
    try {
      const t = await navigator.clipboard.readText();
      if (t) { $('text').value = $('text').value ? $('text').value + '\n\n' + t : t; updateCount(); saveDraft(); }
    } catch (e) {
      showMsg('Can’t read the clipboard here. Long-press in the text box and choose Paste.');
    }
  }

  function init() {
    buildSegs();
    const saved = store.get('pm.settings');
    if (saved) settings = Object.assign({}, DEFAULTS, saved);
    applySettings();
    const d = store.get('pm.draft');
    if (d) { $('title').value = d.title || ''; $('text').value = d.text || ''; }
    updateCount();

    $('text').addEventListener('input', () => { updateCount(); saveDraft(); showMsg(''); });
    $('title').addEventListener('input', saveDraft);
    $('keep').addEventListener('change', () => { settings.keep = $('keep').checked; store.set('pm.settings', settings); });
    $('gen').addEventListener('click', generate);
    $('btnSave').addEventListener('click', save);
    $('btnShare').addEventListener('click', share);
    $('btnPaste').addEventListener('click', paste);
    $('btnSample').addEventListener('click', () => { $('title').value = SAMPLE.title; $('text').value = SAMPLE.text; updateCount(); saveDraft(); showMsg(''); });
    $('btnClear').addEventListener('click', () => { $('title').value = ''; $('text').value = ''; updateCount(); saveDraft(); showMsg(''); showWarn(''); $('result').hidden = true; });

    if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
      navigator.serviceWorker.register('sw.js').catch((e) => console.warn('SW failed', e));
      navigator.serviceWorker.ready.then(() => { $('offlinePill').hidden = false; });
    }
  }
  document.addEventListener('DOMContentLoaded', init);
})(window.PM = window.PM || {});
