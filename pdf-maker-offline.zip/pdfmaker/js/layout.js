/* layout.js - word wrapping, alignment, lists, headings, page breaks, page numbers */
(function (PM) {
  'use strict';
  const COLORS = {
    text: [0.09, 0.09, 0.11], head: [0.1, 0.16, 0.3], quote: [0.3, 0.3, 0.34],
    foot: [0.45, 0.45, 0.5], rule: [0.78, 0.79, 0.83], bar: [0.6, 0.64, 0.75]
  };
  const key = (b, i) => (b && i ? 'bi' : b ? 'b' : i ? 'i' : 'r');

  PM.neededStyles = function (blocks, hasTitle) {
    const s = new Set(['r']);
    if (hasTitle) s.add('b');
    for (const b of blocks) {
      if (b.type === 'heading') s.add('b');
      if (b.type === 'quote') s.add('i');
      if (b.runs) for (const r of b.runs) s.add(key(r.b || b.type === 'heading', r.i || b.type === 'quote'));
    }
    return [...s];
  };

  /* o: {pageW,pageH,margin,size,align,spacing}  */
  PM.layout = function (blocks, title, o, fonts) {
    const { pageW, pageH, margin, size: sz, align, spacing } = o;
    const reg = fonts.r;
    const contentW = pageW - 2 * margin;
    const asc = reg.asc / reg.upm, desc = reg.desc / reg.upm;
    const missing = new Set();
    const loaded = Object.values(fonts);

    const supported = (cp) => loaded.every((f) => f.gid(cp));
    function sanitize(t) {
      let out = '';
      for (const ch of t.replace(/\t/g, '    ')) {
        const cp = ch.codePointAt(0);
        if (ch === '\n') { out += ch; continue; }
        if (cp < 32 || cp === 0x7f) continue;
        if (cp === 0xA0 || (cp >= 0x2000 && cp <= 0x200A) || cp === 0x202F || cp === 0x3000) { out += ' '; continue; }
        if (cp === 0x200B || cp === 0x200C || cp === 0x200D || cp === 0xFEFF || cp === 0xAD ||
            (cp >= 0x200E && cp <= 0x200F) || (cp >= 0xFE00 && cp <= 0xFE0F)) continue;
        if (supported(cp)) out += ch; else { missing.add(ch); out += '?'; }
      }
      return out;
    }
    function measure(text, k, size) {
      const f = fonts[k] || reg; let w = 0;
      for (const ch of text) w += f.adv(f.gid(ch.codePointAt(0)));
      return (w * size) / f.upm;
    }

    function tokenize(runs, baseB, baseI, size) {
      const toks = []; let cur = null;
      const flush = () => { if (cur) { cur.w = cur.frags.reduce((a, f) => a + f.w, 0); toks.push(cur); cur = null; } };
      for (const r of runs) {
        const k = key(baseB || r.b, baseI || r.i);
        for (const part of sanitize(r.t).split(/(\s+)/)) {
          if (part === '') continue;
          if (/^\s+$/.test(part)) {
            flush();
            const nl = (part.match(/\n/g) || []).length;
            if (nl) for (let n = 0; n < nl; n++) toks.push({ type: 'br' });
            else toks.push({ type: 'sp', w: measure(' ', k, size) });
          } else {
            if (!cur) cur = { type: 'w', frags: [] };
            cur.frags.push({ text: part, k, w: measure(part, k, size) });
          }
        }
      }
      flush();
      return toks;
    }

    function splitWord(word, avail, size) {
      const pieces = []; let cur = { frags: [], w: 0 };
      for (const fr of word.frags) {
        let txt = '';
        const pushTxt = () => { if (txt) { cur.frags.push({ text: txt, k: fr.k, w: measure(txt, fr.k, size) }); cur.w += measure(txt, fr.k, size); txt = ''; } };
        for (const ch of fr.text) {
          const cw = measure(ch, fr.k, size);
          if (cur.w + measure(txt + ch, fr.k, size) > avail && (cur.w > 0 || txt)) { pushTxt(); pieces.push(cur); cur = { frags: [], w: 0 }; }
          txt += ch;
        }
        pushTxt();
      }
      if (cur.frags.length) pieces.push(cur);
      return pieces;
    }

    function breakLines(toks, avail, size) {
      const lines = []; let cur = { items: [], w: 0, spaces: 0, hard: false }; let pend = null;
      const fin = (hard) => { if (cur.items.length) { cur.hard = hard; lines.push(cur); } cur = { items: [], w: 0, spaces: 0, hard: false }; pend = null; };
      for (const t of toks) {
        if (t.type === 'br') { fin(true); continue; }
        if (t.type === 'sp') { if (cur.items.length) pend = t; continue; }
        let pieces = [t];
        if (t.w > avail + 0.01) { fin(false); pieces = splitWord(t, avail, size); }
        pieces.forEach((pc, pi) => {
          const sw = cur.items.length && pend ? pend.w : 0;
          if (cur.items.length && cur.w + sw + pc.w > avail + 0.01) { fin(false); }
          if (cur.items.length && pend) { cur.items.push(pend); cur.w += pend.w; cur.spaces++; }
          cur.items.push(pc); cur.w += pc.w; pend = null;
          if (pi < pieces.length - 1) fin(false);
        });
      }
      fin(true);
      return lines;
    }

    /* runs -> positioned lines */
    function makeLines(runs, opt) {
      const toks = tokenize(runs, !!opt.baseB, !!opt.baseI, opt.sz);
      return breakLines(toks, opt.avail, opt.sz).map((L) => {
        let x = 0, extra = 0;
        if (opt.align === 'center') x = (opt.avail - L.w) / 2;
        else if (opt.align === 'right') x = opt.avail - L.w;
        else if (opt.align === 'justify' && !L.hard && L.spaces > 0) extra = (opt.avail - L.w) / L.spaces;
        const segs = [];
        for (const it of L.items) {
          if (it.frags) for (const f of it.frags) { segs.push({ text: f.text, k: f.k, x }); x += f.w; }
          else x += it.w + extra;
        }
        return { segs, h: opt.lh, sz: opt.sz };
      });
    }

    const sideAlign = align === 'center' || align === 'right' ? align : 'left';
    const lhBody = sz * 1.2 * spacing;
    const all = [];

    if (title && title.trim()) {
      const ts = sz * 1.9;
      all.push({ lines: makeLines([{ t: title.trim().replace(/\s+/g, ' '), b: true, i: false }], { baseB: true, sz: ts, avail: contentW, align: 'center', lh: ts * 1.2 * Math.min(spacing, 1.3) }),
        before: 0, after: sz * 0.5, keepNext: true, left: 0, color: COLORS.head });
      all.push({ rule: true, lines: [], h: 1, before: 0, after: sz * 1.1, keepNext: false, color: COLORS.rule });
    }

    for (const b of blocks) {
      if (b.type === 'rule') { all.push({ rule: true, lines: [], h: 1, before: sz * 0.6, after: sz * 0.9, color: COLORS.rule }); continue; }
      if (b.type === 'heading') {
        const hs = sz * [1.6, 1.35, 1.15][b.level - 1];
        all.push({ lines: makeLines(b.runs, { baseB: true, sz: hs, avail: contentW, align: sideAlign, lh: hs * 1.2 * Math.min(spacing, 1.3) }),
          before: hs * 0.9, after: hs * 0.35, keepNext: true, left: 0, color: COLORS.head });
      } else if (b.type === 'para') {
        all.push({ lines: makeLines(b.runs, { sz, avail: contentW, align, lh: lhBody }), before: 0, after: sz * 0.65, left: 0, color: COLORS.text });
      } else if (b.type === 'quote') {
        const left = sz * 1.5;
        all.push({ lines: makeLines(b.runs, { baseI: true, sz, avail: contentW - left, align: sideAlign === 'left' && align === 'justify' ? 'justify' : sideAlign, lh: lhBody }),
          before: sz * 0.2, after: sz * 0.8, left, bar: sz * 0.55, color: COLORS.quote });
      } else if (b.type === 'li') {
        const lvl = b.level * sz * 1.6;
        const hang = Math.max(sz * 1.4, measure(b.marker, 'r', sz) + sz * 0.5);
        const left = lvl + hang;
        const lines = makeLines(b.runs, { sz, avail: contentW - left, align: align === 'justify' ? 'justify' : 'left', lh: lhBody });
        if (lines.length) lines[0].marker = { text: b.marker, x: lvl };
        all.push({ lines, before: 0, after: b.last ? sz * 0.65 : sz * 0.28, left, color: COLORS.text });
      }
    }
    const blocksL = all.filter((b) => b.rule || b.lines.length);

    /* ---- placement & pagination ---- */
    const pages = [];
    const top = margin, limit = pageH - margin;
    let page, cursor, atTop;
    const newPage = () => { page = { ops: [] }; pages.push(page); cursor = top; atTop = true; };
    newPage();
    const totalOf = (b) => (b.rule ? b.h : b.lines.reduce((a, l) => a + l.h, 0));
    const firstH = (b, n) => (b.rule ? b.h : b.lines.slice(0, n).reduce((a, l) => a + l.h, 0));
    const halfLead = (h, s) => (h - (asc + desc) * s) / 2;

    function emit(b, l) {
      const base = cursor + halfLead(l.h, l.sz) + asc * l.sz;
      const y = pageH - base;
      if (l.marker) page.ops.push({ k: 't', x: margin + l.marker.x, y, text: l.marker.text, style: 'r', size: l.sz, color: COLORS.text });
      for (const s of l.segs) page.ops.push({ k: 't', x: margin + b.left + s.x, y, text: s.text, style: s.k, size: l.sz, color: b.color });
    }

    let prev = null;
    for (let idx = 0; idx < blocksL.length; idx++) {
      const b = blocksL[idx];
      const total = totalOf(b);
      let gap = atTop || !prev ? 0 : Math.max(prev.after, b.before);

      if (b.keepNext && !atTop) {
        let need = gap + total, cur = b, j = idx;
        while (cur.keepNext && blocksL[j + 1]) {
          const nb = blocksL[j + 1];
          need += Math.max(cur.after, nb.before) + (nb.keepNext ? totalOf(nb) : firstH(nb, 2));
          cur = nb; j++;
        }
        if (cursor + need > limit) { newPage(); gap = 0; }
      }

      if (b.rule) {
        if (cursor + gap + b.h > limit && !atTop) { newPage(); gap = 0; }
        cursor += gap;
        page.ops.push({ k: 'line', x1: margin, x2: pageW - margin, y1: pageH - cursor - 0.5, y2: pageH - cursor - 0.5, w: 1, color: b.color });
        cursor += b.h; prev = b; atTop = false;
        continue;
      }

      const n = b.lines.length; let i = 0;
      while (i < n) {
        const room = limit - cursor - gap;
        let k = 0, hs = 0;
        while (i + k < n && hs + b.lines[i + k].h <= room + 0.01) { hs += b.lines[i + k].h; k++; }
        const kFit = k, rem = n - i;
        if (k < rem) {
          if (rem - k === 1) k--;
          if (i === 0 && (k < 2 || n <= 3)) k = 0;
          if (k <= 0) {
            if (!atTop) { newPage(); gap = 0; continue; }
            k = Math.max(1, kFit);
          }
        }
        cursor += gap; gap = 0;
        const startY = cursor;
        for (const l of b.lines.slice(i, i + k)) { emit(b, l); cursor += l.h; }
        if (b.bar) page.ops.push({ k: 'rect', x: margin + b.bar, y: pageH - cursor, w: 2.5, h: cursor - startY, color: COLORS.bar });
        i += k; atTop = false;
        if (i < n) newPage();
      }
      prev = b;
    }

    /* footer: page numbers */
    const N = pages.length;
    pages.forEach((pg, idx) => {
      const txt = 'Page ' + (idx + 1) + ' of ' + N;
      const w = measure(txt, 'r', 9);
      pg.ops.push({ k: 't', x: (pageW - w) / 2, y: Math.max(16, margin * 0.5), text: txt, style: 'r', size: 9, color: COLORS.foot });
    });
    return { pages, missing: [...missing] };
  };
})(window.PM = window.PM || {});
