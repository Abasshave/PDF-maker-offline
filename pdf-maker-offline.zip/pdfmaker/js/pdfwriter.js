/* pdfwriter.js - tiny dependency-free PDF writer with embedded TrueType (Unicode) fonts */
(function (PM) {
  'use strict';
  const enc = new TextEncoder();
  const n2 = (n) => (Math.round(n * 100) / 100).toString();
  const n3 = (n) => (Math.round(n * 1000) / 1000).toString();
  const hex4 = (n) => n.toString(16).padStart(4, '0').toUpperCase();
  const utf16hex = (str) => { let h = ''; for (let i = 0; i < str.length; i++) h += hex4(str.charCodeAt(i)); return h; };

  async function deflate(u8) {
    if (typeof CompressionStream === 'undefined') return null;
    const cs = new CompressionStream('deflate');
    const w = cs.writable.getWriter();
    w.write(u8); w.close();
    return new Uint8Array(await new Response(cs.readable).arrayBuffer());
  }

  /* ---------- TrueType parser (cmap, hmtx, head, hhea, OS/2, post) ---------- */
  PM.parseTTF = function (buf, psName) {
    const dv = new DataView(buf);
    if (dv.getUint32(0) === 0x74746366) throw new Error('TTC fonts are not supported');
    const num = dv.getUint16(4);
    const T = {};
    for (let i = 0; i < num; i++) {
      const o = 12 + i * 16;
      const tag = String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3));
      T[tag] = { off: dv.getUint32(o + 8), len: dv.getUint32(o + 12) };
    }
    const head = T.head.off, hhea = T.hhea.off, maxp = T.maxp.off, hmtx = T.hmtx.off;
    const upm = dv.getUint16(head + 18);
    const bbox = [dv.getInt16(head + 36), dv.getInt16(head + 38), dv.getInt16(head + 40), dv.getInt16(head + 42)];
    const asc = dv.getInt16(hhea + 4), desc = -dv.getInt16(hhea + 6);
    const nHM = dv.getUint16(hhea + 34);
    const numGlyphs = dv.getUint16(maxp + 4);
    const advances = new Uint16Array(numGlyphs);
    for (let g = 0; g < numGlyphs; g++) advances[g] = dv.getUint16(hmtx + 4 * Math.min(g, nHM - 1));
    const italicAngle = T.post ? dv.getInt32(T.post.off + 4) / 65536 : 0;
    let capHeight = Math.round(asc * 0.78);
    if (T['OS/2'] && dv.getUint16(T['OS/2'].off) >= 2 && T['OS/2'].len >= 90) {
      const c = dv.getInt16(T['OS/2'].off + 88); if (c > 0) capHeight = c;
    }

    // cmap -> Map(codepoint -> glyph id)
    const cm = T.cmap.off;
    const nSub = dv.getUint16(cm + 2);
    let best = null;
    for (let i = 0; i < nSub; i++) {
      const pid = dv.getUint16(cm + 4 + i * 8), eid = dv.getUint16(cm + 6 + i * 8), off = cm + dv.getUint32(cm + 8 + i * 8);
      const fmt = dv.getUint16(off);
      const score = (pid === 3 && eid === 10 && fmt === 12) ? 4 : (pid === 0 && fmt === 12) ? 3 : (pid === 3 && eid === 1 && fmt === 4) ? 2 : (pid === 0 && fmt === 4) ? 1 : 0;
      if (score && (!best || score > best.score)) best = { score, off, fmt };
    }
    if (!best) throw new Error('Font has no usable Unicode cmap');
    const map = new Map();
    const o = best.off;
    if (best.fmt === 12) {
      const ng = dv.getUint32(o + 12);
      for (let i = 0; i < ng; i++) {
        const s = dv.getUint32(o + 16 + i * 12), e = dv.getUint32(o + 20 + i * 12), g = dv.getUint32(o + 24 + i * 12);
        for (let c = s; c <= e; c++) map.set(c, g + (c - s));
      }
    } else {
      const segX2 = dv.getUint16(o + 6), segs = segX2 / 2;
      const endP = o + 14, startP = o + 16 + segX2, deltaP = o + 16 + 2 * segX2, rangeP = o + 16 + 3 * segX2;
      for (let i = 0; i < segs; i++) {
        const end = dv.getUint16(endP + i * 2), start = dv.getUint16(startP + i * 2);
        const delta = dv.getInt16(deltaP + i * 2), ro = dv.getUint16(rangeP + i * 2);
        for (let c = start; c <= end && c !== 0xFFFF; c++) {
          let g;
          if (ro === 0) g = (c + delta) & 0xFFFF;
          else { g = dv.getUint16(rangeP + i * 2 + ro + (c - start) * 2); if (g) g = (g + delta) & 0xFFFF; }
          if (g) map.set(c, g);
        }
      }
    }
    const locaFmt = dv.getInt16(head + 50);
    return {
      glyf: T.glyf ? T.glyf.off : 0, loca: T.loca ? T.loca.off : 0, locaFmt, numGlyphs,
      psName: psName || 'Font', data: new Uint8Array(buf), upm, asc, desc, bbox, italicAngle, capHeight,
      gid: (cp) => map.get(cp) || 0,
      adv: (g) => advances[g] || 0
    };
  };

  /* Zero out glyph outlines that are not used (glyph ids stay the same), so the font compresses to a fraction. */
  function subsetFont(f, gidSet) {
    const data = f.data.slice();
    if (!f.glyf || !f.loca) return data;
    const dv = new DataView(data.buffer);
    const off = (g) => (f.locaFmt ? dv.getUint32(f.loca + g * 4) : dv.getUint16(f.loca + g * 2) * 2);
    const keep = new Set([0]);
    const add = (g) => {
      if (keep.has(g) && g !== 0) return;
      keep.add(g);
      const s = off(g), e = off(g + 1);
      if (e <= s) return;
      let p = f.glyf + s;
      if (dv.getInt16(p) >= 0) return;
      p += 10;
      for (;;) {
        const flags = dv.getUint16(p), gi = dv.getUint16(p + 2);
        add(gi);
        p += 4 + (flags & 1 ? 4 : 2);
        if (flags & 8) p += 2; else if (flags & 0x40) p += 4; else if (flags & 0x80) p += 8;
        if (!(flags & 0x20)) break;
      }
    };
    gidSet.forEach(add);
    for (let g = 0; g < f.numGlyphs; g++) {
      if (keep.has(g)) continue;
      const s = off(g), e = off(g + 1);
      if (e > s) data.fill(0, f.glyf + s, f.glyf + e);
    }
    return data;
  }

  /* ---------- PDF assembly ---------- */
  async function streamObj(dict, bytes, compress) {
    let data = bytes, filt = '';
    if (compress) {
      const z = await deflate(bytes);
      if (z) { data = z; filt = ' /Filter /FlateDecode'; }
    }
    return ['<< ' + dict + filt + ' /Length ' + data.length + ' >>\nstream\n', data, '\nendstream'];
  }

  /*  pages: [{ops:[...]}]  ops: {k:'t',x,y,text,style,size,color} | {k:'rect',x,y,w,h,color} | {k:'line',x1,y1,x2,y2,w,color}  */
  PM.buildPDF = async function ({ pages, pageW, pageH, fonts, title }) {
    const keys = Object.keys(fonts);
    const fname = {}; keys.forEach((k, i) => { fname[k] = 'F' + (i + 1); });
    const used = {}; keys.forEach((k) => { used[k] = new Map(); });
    const rg = (c) => n3(c[0]) + ' ' + n3(c[1]) + ' ' + n3(c[2]);

    const contents = pages.map((pg) => {
      const out = [];
      for (const op of pg.ops) {
        if (op.k === 't') {
          const f = fonts[op.style] || fonts.r;
          const key = fonts[op.style] ? op.style : 'r';
          let hx = '';
          for (const ch of op.text) {
            const cp = ch.codePointAt(0);
            let g = f.gid(cp);
            if (!g) g = f.gid(63);
            used[key].set(g, cp);
            hx += hex4(g);
          }
          out.push('BT /' + fname[key] + ' ' + n2(op.size) + ' Tf ' + rg(op.color) + ' rg 1 0 0 1 ' + n2(op.x) + ' ' + n2(op.y) + ' Tm <' + hx + '> Tj ET');
        } else if (op.k === 'rect') {
          out.push(rg(op.color) + ' rg ' + n2(op.x) + ' ' + n2(op.y) + ' ' + n2(op.w) + ' ' + n2(op.h) + ' re f');
        } else if (op.k === 'line') {
          out.push(n2(op.w) + ' w ' + rg(op.color) + ' RG ' + n2(op.x1) + ' ' + n2(op.y1) + ' m ' + n2(op.x2) + ' ' + n2(op.y2) + ' l S');
        }
      }
      return enc.encode(out.join('\n'));
    });

    const objs = [null, null, null]; // 1 catalog, 2 pages, 3 info
    const add = (parts) => { objs.push(parts); return objs.length; };

    const fontRefs = {};
    for (const k of keys) {
      const f = fonts[k];
      const ff = add(await streamObj('/Length1 ' + f.data.length, subsetFont(f, used[k].keys()), true));
      const flags = 32 | (f.italicAngle ? 64 : 0);
      const sc = 1000 / f.upm;
      const fd = add(['<< /Type /FontDescriptor /FontName /' + f.psName + ' /Flags ' + flags +
        ' /FontBBox [' + f.bbox.map((v) => Math.round(v * sc)).join(' ') + '] /ItalicAngle ' + n2(f.italicAngle) +
        ' /Ascent ' + Math.round(f.asc * sc) + ' /Descent ' + Math.round(-f.desc * sc) + ' /CapHeight ' + Math.round(f.capHeight * sc) +
        ' /StemV 80 /FontFile2 ' + ff + ' 0 R >>']);
      const gids = [...used[k].keys()].sort((a, b) => a - b);
      const W = gids.map((g) => g + ' [' + Math.round(f.adv(g) * sc) + ']').join(' ');
      const cid = add(['<< /Type /Font /Subtype /CIDFontType2 /BaseFont /' + f.psName +
        ' /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor ' + fd +
        ' 0 R /CIDToGIDMap /Identity /DW 600 /W [' + W + '] >>']);
      let cmap = '/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n';
      for (let i = 0; i < gids.length; i += 100) {
        const chunk = gids.slice(i, i + 100);
        cmap += chunk.length + ' beginbfchar\n' + chunk.map((g) => '<' + hex4(g) + '> <' + utf16hex(String.fromCodePoint(used[k].get(g))) + '>').join('\n') + '\nendbfchar\n';
      }
      cmap += 'endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend';
      const tu = add(await streamObj('', enc.encode(cmap), true));
      fontRefs[k] = add(['<< /Type /Font /Subtype /Type0 /BaseFont /' + f.psName + ' /Encoding /Identity-H /DescendantFonts [' + cid + ' 0 R] /ToUnicode ' + tu + ' 0 R >>']);
    }

    const fontRes = keys.map((k) => '/' + fname[k] + ' ' + fontRefs[k] + ' 0 R').join(' ');
    const pageIds = [];
    for (let i = 0; i < pages.length; i++) {
      const cid = add(await streamObj('', contents[i], true));
      pageIds.push(add(['<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + n2(pageW) + ' ' + n2(pageH) + '] /Resources << /Font << ' + fontRes + ' >> >> /Contents ' + cid + ' 0 R >>']));
    }
    objs[0] = ['<< /Type /Catalog /Pages 2 0 R >>'];
    objs[1] = ['<< /Type /Pages /Count ' + pageIds.length + ' /Kids [' + pageIds.map((id) => id + ' 0 R').join(' ') + '] >>'];
    const d = new Date(), p2 = (x) => String(x).padStart(2, '0');
    const date = 'D:' + d.getUTCFullYear() + p2(d.getUTCMonth() + 1) + p2(d.getUTCDate()) + p2(d.getUTCHours()) + p2(d.getUTCMinutes()) + p2(d.getUTCSeconds()) + 'Z';
    objs[2] = ['<< /Title <FEFF' + utf16hex(title || 'Document') + '> /Producer (PDF Maker Offline) /CreationDate (' + date + ') >>'];

    const chunks = []; let off = 0;
    const push = (c) => { const u = typeof c === 'string' ? enc.encode(c) : c; chunks.push(u); off += u.length; };
    push('%PDF-1.5\n'); push(new Uint8Array([0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A]));
    const offsets = [];
    objs.forEach((parts, i) => {
      offsets[i] = off;
      push((i + 1) + ' 0 obj\n'); parts.forEach(push); push('\nendobj\n');
    });
    const xref = off;
    let x = 'xref\n0 ' + (objs.length + 1) + '\n0000000000 65535 f \n';
    offsets.forEach((o) => { x += String(o).padStart(10, '0') + ' 00000 n \n'; });
    x += 'trailer\n<< /Size ' + (objs.length + 1) + ' /Root 1 0 R /Info 3 0 R >>\nstartxref\n' + xref + '\n%%EOF\n';
    push(x);
    const total = new Uint8Array(off); let p = 0;
    for (const c of chunks) { total.set(c, p); p += c.length; }
    return total;
  };
})(window.PM = window.PM || {});
