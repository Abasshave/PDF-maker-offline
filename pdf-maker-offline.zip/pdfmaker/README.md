# PDF Maker Offline (v1, web/PWA)

Paste text, get a neatly formatted PDF. No internet, no external libraries, no CDN.

## Run locally
    python3 -m http.server 8080      # or: npx serve .
Open http://localhost:8080 (must be a server, not double-clicking index.html, because fonts load with fetch).

## Test offline
1. Open the page once (a green "Ready offline" tag appears).
2. DevTools > Network > Offline (or turn off Wi-Fi), reload, generate a PDF.

## Text rules
- `# Heading`, `## Heading`, `### Heading`, or a short ALL CAPS line on its own = heading
- `- item`, `* item`, `• item` = bullets (indent 2+ spaces for sub-items); `1.` / `1)` = numbered
- `**bold**`, `*italic*`, `***both***`, `\*` = literal asterisk
- `> text` = quote, `---` = divider line
- Blank line = new paragraph. Tick "Keep line breaks" to keep single line breaks.

## Files
- js/parser.js    text -> blocks
- js/layout.js    wrapping, justify, lists, page breaks, page numbers
- js/pdfwriter.js dependency-free PDF writer + TrueType font embedding (subsetted)
- js/app.js       UI
- sw.js, manifest.json   offline + install. Bump VERSION in sw.js when you change files.
- fonts/          DejaVu Sans (free licence): Latin, Greek, Cyrillic, extended Latin (e.g. Yoruba)

## Limits
- Not supported: Arabic/Hebrew (right-to-left, joining), Chinese/Japanese/Korean, Indic scripts. Unsupported characters become "?" and a warning is shown.
- Android APK: normal browser downloads do not work inside the APK. Next step uses Capacitor Filesystem + Share plugins.
