/* Service worker: cache everything on install, serve cache-first. Bump VERSION when files change. */
const VERSION = 'pdfmaker-v1';
const FILES = [
  './', 'index.html', 'manifest.json', 'css/style.css',
  'js/parser.js', 'js/pdfwriter.js', 'js/layout.js', 'js/app.js',
  'fonts/DejaVuSans-Regular.ttf', 'fonts/DejaVuSans-Bold.ttf', 'fonts/DejaVuSans-Oblique.ttf', 'fonts/DejaVuSans-BoldOblique.ttf',
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png'
];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request)));
});
